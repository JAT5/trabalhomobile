package com.example.layout;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class imcActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc);

        mainIMC();
    }

    public void mainIMC(){

        final EditText editPeso = (EditText) findViewById(R.id.editPeso);
        final EditText editAltura = (EditText) findViewById(R.id.editAltura);
        final EditText editIdeal = (EditText) findViewById(R.id.editIdeal);
        final EditText editIMC = (EditText) findViewById(R.id.editIMC);
        final EditText editInterpretacao = (EditText) findViewById(R.id.editInterpretacao);

        final Button btnCalcular = findViewById(R.id.btnCalcular);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if( editPeso.getText() != null && editAltura.getText() != null){

                    double altura = Double.parseDouble(editAltura.getText().toString());

                    double peso = Double.parseDouble(editPeso.getText().toString());

                    double pesoIdeal = setPesoIdeal( altura, peso );

                    double IMC = setIMC( altura, peso);

                    editIMC.setText(String.valueOf(IMC));

                    if( IMC < 20 ){
                        editInterpretacao.setText("Baixo Peso");
                    } else if( IMC < 25 ){
                        editInterpretacao.setText("Normal");
                    } else if( IMC < 30 ){
                        editInterpretacao.setText("Acima do Peso");
                    } else if( IMC > 30 ){
                        editInterpretacao.setText("Obeso");
                    } else {
                        editInterpretacao.setText("Erro 404");
                    }

                    if( !Double.isNaN(pesoIdeal) ){
                        editIdeal.setText(String.valueOf(pesoIdeal));
                    }

                } else {

                    Toast.makeText(imcActivity.this, "Preencha os campos e tente novamente.", Toast.LENGTH_LONG).show();

                }

            }
        });


    }

    public double setPesoIdeal( double altura, double peso ){

        double pesoIdeal;

        altura = altura * 100;

        double a = altura - 100;
        double b = altura - peso;

        b = b/4;

        double x = 5/100;

        pesoIdeal = b * x;
        pesoIdeal = a - pesoIdeal;

        return pesoIdeal;

    }

    public double setIMC(double altura, double peso){

        double IMC;

        double altura2 = altura * altura;

        IMC = peso / altura2;

        return IMC;

    }

}
