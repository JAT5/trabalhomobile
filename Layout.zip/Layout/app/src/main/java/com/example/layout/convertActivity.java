package com.example.layout;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class convertActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convert);

        mainConvert();
    }

    public void mainConvert(){

        final EditText editPrice = (EditText) findViewById(R.id.editPriceDol);
        final EditText editQnt = (EditText) findViewById(R.id.editQntDol);
        final EditText editVal = (EditText) findViewById(R.id.editValReais);


        final Button btnCalcular = findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (editPrice.getText() != null && editQnt.getText() != null) {

                    Double price = Double.parseDouble(editPrice.getText().toString());

                    Double qnt = Double.parseDouble(editQnt.getText().toString());

                    Double value = price * qnt;

                    editVal.setText(String.valueOf(value));


                } else {

                    Toast.makeText(convertActivity.this, "Preencha os campos e tente novamente.", Toast.LENGTH_LONG).show();

                }

            }


        });

    }

}
