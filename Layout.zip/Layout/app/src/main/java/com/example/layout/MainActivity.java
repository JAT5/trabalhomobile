package com.example.layout;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btnEntrar;
    private Button btnConvercao;
    private Button btnDisq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnEntrar = findViewById(R.id.btnIMC);
        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, imcActivity.class);
                startActivity(it);
            }
        });

        btnConvercao = findViewById(R.id.btnConvert);
        btnConvercao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2 = new Intent(MainActivity.this, convertActivity.class);
                startActivity(it2);
            }
        });

        btnDisq = findViewById(R.id.btnDisquete);
        btnDisq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it3 = new Intent(MainActivity.this, disqueteActivity.class);
                startActivity(it3);
            }
        });



    }
}
